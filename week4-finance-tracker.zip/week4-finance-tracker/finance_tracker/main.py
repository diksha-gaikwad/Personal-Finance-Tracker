from finance_tracker.expense import Expense
from finance_tracker.file_handler import load_expenses, save_expenses, backup_data
from finance_tracker.reports import category_breakdown
from finance_tracker.utils import print_line

class FinanceTracker:
    def __init__(self):
        self.expenses = load_expenses()

    def run(self):
        print_line()
        print("PERSONAL FINANCE TRACKER")
        print_line()

        while True:
            print("\n1. Add Expense")
            print("2. View Expenses")
            print("3. Category Report")
            print("4. Backup Data")
            print("0. Exit")

            choice = input("Choice: ")

            if choice == "1":
                self.add_expense()
            elif choice == "2":
                self.view_expenses()
            elif choice == "3":
                self.show_report()
            elif choice == "4":
                backup_data()
                print("✅ Backup created")
            elif choice == "0":
                print("Bye 👋")
                break
            else:
                print("Invalid choice")

    def add_expense(self):
        date = input("Date (YYYY-MM-DD): ")
        amount = input("Amount: ")
        category = input("Category: ")
        description = input("Description: ")

        expense = Expense(date, amount, category, description)
        self.expenses.append(expense.to_dict())
        save_expenses(self.expenses)

        print("✅ Expense added")

    def view_expenses(self):
        for e in self.expenses:
            print(e)

    def show_report(self):
        report = category_breakdown(self.expenses)
        for k, v in report.items():
            print(f"{k}: {v}")
