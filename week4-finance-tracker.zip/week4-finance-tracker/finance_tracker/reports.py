def category_breakdown(expenses):
    result = {}

    for e in expenses:
        cat = e["category"]
        result[cat] = result.get(cat, 0) + e["amount"]

    return result
