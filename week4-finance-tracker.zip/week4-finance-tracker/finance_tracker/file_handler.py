import json
import os
from datetime import datetime

DATA_FILE = "data/expenses.json"
BACKUP_DIR = "data/backup"

def load_expenses():
    if not os.path.exists(DATA_FILE):
        return []

    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_expenses(expenses):
    os.makedirs("data", exist_ok=True)

    with open(DATA_FILE, "w") as f:
        json.dump(expenses, f, indent=4)

def backup_data():
    os.makedirs(BACKUP_DIR, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"{BACKUP_DIR}/expenses_{timestamp}.json"

    with open(DATA_FILE, "r") as src:
        data = src.read()

    with open(backup_file, "w") as dest:
        dest.write(data)
