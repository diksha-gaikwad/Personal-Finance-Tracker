def print_line():
    print("=" * 50)
