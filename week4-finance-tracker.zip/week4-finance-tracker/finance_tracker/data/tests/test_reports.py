from finance_tracker.reports import category_breakdown

def test_report():
    data = [
        {"category": "Food", "amount": 100},
        {"category": "Food", "amount": 50}
    ]
    report = category_breakdown(data)
    assert report["Food"] == 150
