from finance_tracker.file_handler import save_expenses, load_expenses

def test_save_load():
    data = [{"date": "2024-01-01", "amount": 100, "category": "Food"}]
    save_expenses(data)
    loaded = load_expenses()
    assert loaded[0]["amount"] == 100
