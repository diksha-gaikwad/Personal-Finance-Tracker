from finance_tracker.main import FinanceTracker

if __name__ == "__main__":
    FinanceTracker().run()
